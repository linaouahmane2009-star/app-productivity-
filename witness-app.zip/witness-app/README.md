# Witness

App d'accountability : tu fixes un objectif, tu assignes un ami comme "témoin",
et il confirme si tu l'as atteint avant la deadline. Marche pour le sport,
les études, les projets perso — n'importe quel objectif.

## Stack

- **Frontend** : React (Vite)
- **Backend / base de données** : Supabase (auth + base de données Postgres)
- **Déploiement** : Vercel

## Statut du projet

Version actuelle : squelette de l'app avec l'interface de base (créer un
objectif + assigner un témoin). La connexion à Supabase n'est pas encore
branchée — les objectifs créés ne sont pour l'instant pas sauvegardés.

## Lancer le projet en local

```bash
npm install
npm run dev
```

## Variables d'environnement

Copier `.env.example` en `.env` et ajouter les clés de votre projet Supabase
(Project Settings → API dans le dashboard Supabase) :

```
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
```

## Équipe

- Dev : [ton nom]
- Design : [nom]
- Marketing : [nom]
